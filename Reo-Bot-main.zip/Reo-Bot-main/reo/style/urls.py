SUPPORT_SERVER = "https://example.com/reo/support"
WEBSITE = "https://example.com/reo"
PRIVACY_POLICY = "https://example.com/reo/privacy"
TERMS_OF_SERVICE = "https://example.com/reo/terms"
VOTE = "https://top.gg/bot/1495642966834942023/vote"
ANTINUKE = "https://media.discordapp.net/attachments/1229366361826918405/1357198281716793424/images_19.jpg?ex=67ef54e5&is=67ee0365&hm=d0ae67d74239866b888bd8fa7dac4fdf51711576ccb5e7c2165c0b62d2bcbd3e&"
INVITE = r"https://discord.com/oauth2/authorize?client_id=1495642966834942023"
GIVEAWAY = "https://media.discordapp.net/attachments/1229366361826918405/1357197689845977188/images_22.jpg?ex=67ef5458&is=67ee02d8&hm=1db47f17ee154a7a71ca3b9d5a73678153ff96cd5b8f40075a02ef01f84293e1&"
TICKET = "https://cdn.discordapp.com/attachments/1286969360224882688/1286969378146877461/6030249.png?ex=66efd722&is=66ee85a2&hm=d1c77d1c703d997bf2742b39fda05757f64ccd3b7758dd1bc9a0ea469507fd35&"

DEFAULT_MUSIC_BANNER = "https://media.discordapp.net/attachments/1229366361826918405/1357196877023547492/images_21.jpg?ex=67ef5396&is=67ee0216&hm=065303d8f2472468d5a0a4813839aadbd08bb10d556739ef9907bece29f4c034&"

